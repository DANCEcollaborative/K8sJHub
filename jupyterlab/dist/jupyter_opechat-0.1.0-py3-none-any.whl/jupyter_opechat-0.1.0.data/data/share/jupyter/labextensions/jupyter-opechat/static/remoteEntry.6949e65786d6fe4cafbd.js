var _JUPYTERLAB;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "webpack/container/entry/jupyter-opechat":
/*!***********************!*\
  !*** container entry ***!
  \***********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var moduleMap = {
	"./index": () => {
		return Promise.all([__webpack_require__.e("webpack_sharing_consume_default_react"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-common_azure_communication-common"), __webpack_require__.e("lib_index_js")]).then(() => (() => ((__webpack_require__(/*! ./lib/index.js */ "./lib/index.js")))));
	},
	"./extension": () => {
		return Promise.all([__webpack_require__.e("webpack_sharing_consume_default_react"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-common_azure_communication-common"), __webpack_require__.e("lib_index_js")]).then(() => (() => ((__webpack_require__(/*! ./lib/index.js */ "./lib/index.js")))));
	},
	"./style": () => {
		return Promise.all([__webpack_require__.e("vendors-node_modules_css-loader_dist_runtime_api_js-node_modules_css-loader_dist_runtime_cssW-72eba1"), __webpack_require__.e("style_index_js")]).then(() => (() => ((__webpack_require__(/*! ./style/index.js */ "./style/index.js")))));
	}
};
var get = (module, getScope) => {
	__webpack_require__.R = getScope;
	getScope = (
		__webpack_require__.o(moduleMap, module)
			? moduleMap[module]()
			: Promise.resolve().then(() => {
				throw new Error('Module "' + module + '" does not exist in container.');
			})
	);
	__webpack_require__.R = undefined;
	return getScope;
};
var init = (shareScope, initScope) => {
	if (!__webpack_require__.S) return;
	var name = "default"
	var oldScope = __webpack_require__.S[name];
	if(oldScope && oldScope !== shareScope) throw new Error("Container initialization failed as it has already been initialized with a different share scope");
	__webpack_require__.S[name] = shareScope;
	return __webpack_require__.I(name, initScope);
};

// This exports getters to disallow modifications
__webpack_require__.d(exports, {
	get: () => (get),
	init: () => (init)
});

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = __webpack_module_cache__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + "." + {"webpack_sharing_consume_default_react":"ac25d4f0875a9efe8ce5","webpack_sharing_consume_default_azure_communication-common_azure_communication-common":"f36f552c9b4013cf6325","lib_index_js":"6fe4471042e12a161fa1","vendors-node_modules_css-loader_dist_runtime_api_js-node_modules_css-loader_dist_runtime_cssW-72eba1":"3be8f5daa65cbdd0a4da","style_index_js":"f701a9c83d8f9be751ad","node_modules_azure_abort-controller_dist-esm_src_index_js":"7ede6af22b8cddc26ead","vendors-node_modules_azure_communication-calling_dist_sdk_bundle_js":"be840fed894dfc37b5ab","webpack_sharing_consume_default_azure_communication-common_azure_communication-common-webpack-bf920b":"043d1685d128679f4254","vendors-node_modules_tslib_tslib_es6_js":"0eb16e99b09b3cd5db4a","vendors-node_modules_azure_core-auth_dist-esm_src_tokenCredential_js-node_modules_azure_core--293e8a":"3f4d4fdaff995829f268","vendors-node_modules_events_events_js":"f7bc0cd2db3b28f0d847","vendors-node_modules_azure_communication-chat_dist-esm_src_index_js":"0270e5e28170b2b3486e","webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller":"fdd5653fe6f682f41153","webpack_sharing_consume_default_azure_logger_azure_logger-_4181":"4339da35b590384feca8","vendors-node_modules_azure_communication-calling_node_modules_azure_communication-common_dist-bdb051":"1e103c21106675f6e81f","vendors-node_modules_azure_communication-react_node_modules_azure_communication-common_dist-e-65f4c5":"c7fef0ef33381b47f5a6","webpack_sharing_consume_default_azure_logger_azure_logger-_56cc":"301bbe644370f4e2de24","vendors-node_modules_azure_communication-common_dist-esm_src_index_js":"abd365f6214c04611ee7","vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338":"f4b4309228f3fd8321c0","vendors-node_modules_azure_communication-react_dist_dist-esm_communication-react_src_index_js":"bed9cd04531986249068","webpack_sharing_consume_default_react-dom":"d90036be26b8f84408b9","webpack_sharing_consume_default_azure_communication-calling_azure_communication-calling-webpa-831138":"5de1f64c012e8ab0ea61","node_modules_azure_communication-calling_node_modules_azure_logger_dist-esm_src_index_js-_b3271":"ef071381c832b1daa3d1","vendors-node_modules_azure_communication-react_node_modules_azure_logger_dist-esm_src_index_js":"dd798e6341217c3e3fb9","vendors-node_modules_azure_communication-react_node_modules_azure_communication-common_node_m-3c2995":"ff607f022d26763d52d7","vendors-node_modules_azure_logger_dist-esm_src_index_js":"5bba354835bea7fc0d73","vendors-node_modules_fluentui_style-utilities_lib_index_js":"9016112801f0ee09fbb3","vendors-node_modules_azure_communication-react_node_modules_fluentui_react-file-type-icons_li-20dab2":"8b6f196759feea7a667c","vendors-node_modules_fluentui_react-file-type-icons_lib_index_js":"39a9ae309ac42063e7e5","vendors-node_modules_azure_communication-react_node_modules_fluentui_react-icons_lib_esm_index_js":"f46f1a5ad5ae0f7472b0","vendors-node_modules_fluentui_react-icons_lib_index_js":"a83d81b0e7b06801e7eb","vendors-node_modules_fluentui_date-time-utilities_lib_dateFormatting_dateFormatting_defaults_-bcc259":"7652d625ec9bc8f8c84a","vendors-node_modules_fluentui_react_lib_index_js":"3d699d6ef3d871770724","vendors-node_modules_azure_communication-react_node_modules_fluentui_react_lib_index_js":"c28edd5c3b25e2d1fe30","node_modules_fluentui_react-hooks_lib_useBoolean_js-node_modules_fluentui_react-hooks_lib_use-a49efb":"a00772bdaabe7be92421","vendors-node_modules_react-linkify_dist_index_js":"d001b8fe2c5b3443fffe","node_modules_azure_communication-react_node_modules_reselect_es_index_js":"fb37a6eb1f307a7276cb","node_modules_azure_communication-calling_node_modules_azure_logger_dist-esm_src_index_js-_b3270":"1a72b04c41af0aa6c442"}[chunkId] + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "jupyter-opechat:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/sharing */
/******/ 	(() => {
/******/ 		__webpack_require__.S = {};
/******/ 		var initPromises = {};
/******/ 		var initTokens = {};
/******/ 		__webpack_require__.I = (name, initScope) => {
/******/ 			if(!initScope) initScope = [];
/******/ 			// handling circular init calls
/******/ 			var initToken = initTokens[name];
/******/ 			if(!initToken) initToken = initTokens[name] = {};
/******/ 			if(initScope.indexOf(initToken) >= 0) return;
/******/ 			initScope.push(initToken);
/******/ 			// only runs once
/******/ 			if(initPromises[name]) return initPromises[name];
/******/ 			// creates a new share scope if needed
/******/ 			if(!__webpack_require__.o(__webpack_require__.S, name)) __webpack_require__.S[name] = {};
/******/ 			// runs all init snippets from all modules reachable
/******/ 			var scope = __webpack_require__.S[name];
/******/ 			var warn = (msg) => {
/******/ 				if (typeof console !== "undefined" && console.warn) console.warn(msg);
/******/ 			};
/******/ 			var uniqueName = "jupyter-opechat";
/******/ 			var register = (name, version, factory, eager) => {
/******/ 				var versions = scope[name] = scope[name] || {};
/******/ 				var activeVersion = versions[version];
/******/ 				if(!activeVersion || (!activeVersion.loaded && (!eager != !activeVersion.eager ? eager : uniqueName > activeVersion.from))) versions[version] = { get: factory, from: uniqueName, eager: !!eager };
/******/ 			};
/******/ 			var initExternal = (id) => {
/******/ 				var handleError = (err) => (warn("Initialization of sharing external failed: " + err));
/******/ 				try {
/******/ 					var module = __webpack_require__(id);
/******/ 					if(!module) return;
/******/ 					var initFn = (module) => (module && module.init && module.init(__webpack_require__.S[name], initScope))
/******/ 					if(module.then) return promises.push(module.then(initFn, handleError));
/******/ 					var initResult = initFn(module);
/******/ 					if(initResult && initResult.then) return promises.push(initResult['catch'](handleError));
/******/ 				} catch(err) { handleError(err); }
/******/ 			}
/******/ 			var promises = [];
/******/ 			switch(name) {
/******/ 				case "default": {
/******/ 					register("@azure/abort-controller", "1.1.0", () => (__webpack_require__.e("node_modules_azure_abort-controller_dist-esm_src_index_js").then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/abort-controller/dist-esm/src/index.js */ "./node_modules/@azure/abort-controller/dist-esm/src/index.js"))))));
/******/ 					register("@azure/communication-calling", "1.13.1", () => (Promise.all([__webpack_require__.e("vendors-node_modules_azure_communication-calling_dist_sdk_bundle_js"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-common_azure_communication-common-webpack-bf920b")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-calling/dist/sdk.bundle.js */ "./node_modules/@azure/communication-calling/dist/sdk.bundle.js"))))));
/******/ 					register("@azure/communication-chat", "1.3.1", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_azure_core-auth_dist-esm_src_tokenCredential_js-node_modules_azure_core--293e8a"), __webpack_require__.e("vendors-node_modules_events_events_js"), __webpack_require__.e("vendors-node_modules_azure_communication-chat_dist-esm_src_index_js"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_4181"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-common_azure_communication-common")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-chat/dist-esm/src/index.js */ "./node_modules/@azure/communication-chat/dist-esm/src/index.js"))))));
/******/ 					register("@azure/communication-common", "2.0.0", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_azure_core-auth_dist-esm_src_tokenCredential_js-node_modules_azure_core--293e8a"), __webpack_require__.e("vendors-node_modules_azure_communication-calling_node_modules_azure_communication-common_dist-bdb051"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_4181")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-calling/node_modules/@azure/communication-common/dist-esm/src/index.js */ "./node_modules/@azure/communication-calling/node_modules/@azure/communication-common/dist-esm/src/index.js"))))));
/******/ 					register("@azure/communication-common", "2.0.0", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_azure_communication-common_dist-e-65f4c5"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_56cc")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/node_modules/@azure/communication-common/dist-esm/src/index.js */ "./node_modules/@azure/communication-react/node_modules/@azure/communication-common/dist-esm/src/index.js"))))));
/******/ 					register("@azure/communication-common", "2.2.0", () => (Promise.all([__webpack_require__.e("vendors-node_modules_azure_core-auth_dist-esm_src_tokenCredential_js-node_modules_azure_core--293e8a"), __webpack_require__.e("vendors-node_modules_azure_communication-common_dist-esm_src_index_js"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_4181")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-common/dist-esm/src/index.js */ "./node_modules/@azure/communication-common/dist-esm/src/index.js"))))));
/******/ 					register("@azure/communication-react", "1.5.0", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_events_events_js"), __webpack_require__.e("vendors-node_modules_azure_communication-react_dist_dist-esm_communication-react_src_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react"), __webpack_require__.e("webpack_sharing_consume_default_react-dom"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-calling_azure_communication-calling-webpa-831138")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/dist/dist-esm/communication-react/src/index.js */ "./node_modules/@azure/communication-react/dist/dist-esm/communication-react/src/index.js"))))));
/******/ 					register("@azure/logger", "1.0.3", () => (__webpack_require__.e("node_modules_azure_communication-calling_node_modules_azure_logger_dist-esm_src_index_js-_b3271").then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-calling/node_modules/@azure/logger/dist-esm/src/index.js */ "./node_modules/@azure/communication-calling/node_modules/@azure/logger/dist-esm/src/index.js"))))));
/******/ 					register("@azure/logger", "1.0.3", () => (__webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_azure_logger_dist-esm_src_index_js").then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/node_modules/@azure/logger/dist-esm/src/index.js */ "./node_modules/@azure/communication-react/node_modules/@azure/logger/dist-esm/src/index.js"))))));
/******/ 					register("@azure/logger", "1.0.4", () => (__webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_azure_communication-common_node_m-3c2995").then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/node_modules/@azure/communication-common/node_modules/@azure/logger/dist-esm/src/index.js */ "./node_modules/@azure/communication-react/node_modules/@azure/communication-common/node_modules/@azure/logger/dist-esm/src/index.js"))))));
/******/ 					register("@azure/logger", "1.0.4", () => (__webpack_require__.e("vendors-node_modules_azure_logger_dist-esm_src_index_js").then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/logger/dist-esm/src/index.js */ "./node_modules/@azure/logger/dist-esm/src/index.js"))))));
/******/ 					register("@fluentui/react-file-type-icons", "8.5.14", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_fluentui_react-file-type-icons_li-20dab2"), __webpack_require__.e("webpack_sharing_consume_default_react")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/node_modules/@fluentui/react-file-type-icons/lib/index.js */ "./node_modules/@azure/communication-react/node_modules/@fluentui/react-file-type-icons/lib/index.js"))))));
/******/ 					register("@fluentui/react-file-type-icons", "8.8.18", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_fluentui_react-file-type-icons_lib_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@fluentui/react-file-type-icons/lib/index.js */ "./node_modules/@fluentui/react-file-type-icons/lib/index.js"))))));
/******/ 					register("@fluentui/react-icons", "1.1.145", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_fluentui_react-icons_lib_esm_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/node_modules/@fluentui/react-icons/lib/esm/index.js */ "./node_modules/@azure/communication-react/node_modules/@fluentui/react-icons/lib/esm/index.js"))))));
/******/ 					register("@fluentui/react-icons", "2.0.202", () => (Promise.all([__webpack_require__.e("vendors-node_modules_fluentui_react-icons_lib_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@fluentui/react-icons/lib/index.js */ "./node_modules/@fluentui/react-icons/lib/index.js"))))));
/******/ 					register("@fluentui/react", "8.109.7", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_fluentui_date-time-utilities_lib_dateFormatting_dateFormatting_defaults_-bcc259"), __webpack_require__.e("vendors-node_modules_fluentui_react_lib_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react"), __webpack_require__.e("webpack_sharing_consume_default_react-dom")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@fluentui/react/lib/index.js */ "./node_modules/@fluentui/react/lib/index.js"))))));
/******/ 					register("@fluentui/react", "8.98.8", () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_fluentui_date-time-utilities_lib_dateFormatting_dateFormatting_defaults_-bcc259"), __webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_fluentui_react_lib_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react"), __webpack_require__.e("webpack_sharing_consume_default_react-dom"), __webpack_require__.e("node_modules_fluentui_react-hooks_lib_useBoolean_js-node_modules_fluentui_react-hooks_lib_use-a49efb")]).then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/node_modules/@fluentui/react/lib/index.js */ "./node_modules/@azure/communication-react/node_modules/@fluentui/react/lib/index.js"))))));
/******/ 					register("jupyter-opechat", "0.1.0", () => (Promise.all([__webpack_require__.e("webpack_sharing_consume_default_react"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-common_azure_communication-common"), __webpack_require__.e("lib_index_js")]).then(() => (() => (__webpack_require__(/*! ./lib/index.js */ "./lib/index.js"))))));
/******/ 					register("react-linkify", "1.0.0-alpha", () => (Promise.all([__webpack_require__.e("vendors-node_modules_react-linkify_dist_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react")]).then(() => (() => (__webpack_require__(/*! ./node_modules/react-linkify/dist/index.js */ "./node_modules/react-linkify/dist/index.js"))))));
/******/ 					register("reselect", "4.0.0", () => (__webpack_require__.e("node_modules_azure_communication-react_node_modules_reselect_es_index_js").then(() => (() => (__webpack_require__(/*! ./node_modules/@azure/communication-react/node_modules/reselect/es/index.js */ "./node_modules/@azure/communication-react/node_modules/reselect/es/index.js"))))));
/******/ 				}
/******/ 				break;
/******/ 			}
/******/ 			if(!promises.length) return initPromises[name] = 1;
/******/ 			return initPromises[name] = Promise.all(promises).then(() => (initPromises[name] = 1));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && !scriptUrl) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/consumes */
/******/ 	(() => {
/******/ 		var parseVersion = (str) => {
/******/ 			// see webpack/lib/util/semver.js for original code
/******/ 			var p=p=>{return p.split(".").map((p=>{return+p==p?+p:p}))},n=/^([^-+]+)?(?:-([^+]+))?(?:\+(.+))?$/.exec(str),r=n[1]?p(n[1]):[];return n[2]&&(r.length++,r.push.apply(r,p(n[2]))),n[3]&&(r.push([]),r.push.apply(r,p(n[3]))),r;
/******/ 		}
/******/ 		var versionLt = (a, b) => {
/******/ 			// see webpack/lib/util/semver.js for original code
/******/ 			a=parseVersion(a),b=parseVersion(b);for(var r=0;;){if(r>=a.length)return r<b.length&&"u"!=(typeof b[r])[0];var e=a[r],n=(typeof e)[0];if(r>=b.length)return"u"==n;var t=b[r],f=(typeof t)[0];if(n!=f)return"o"==n&&"n"==f||("s"==f||"u"==n);if("o"!=n&&"u"!=n&&e!=t)return e<t;r++}
/******/ 		}
/******/ 		var rangeToString = (range) => {
/******/ 			// see webpack/lib/util/semver.js for original code
/******/ 			var r=range[0],n="";if(1===range.length)return"*";if(r+.5){n+=0==r?">=":-1==r?"<":1==r?"^":2==r?"~":r>0?"=":"!=";for(var e=1,a=1;a<range.length;a++){e--,n+="u"==(typeof(t=range[a]))[0]?"-":(e>0?".":"")+(e=2,t)}return n}var g=[];for(a=1;a<range.length;a++){var t=range[a];g.push(0===t?"not("+o()+")":1===t?"("+o()+" || "+o()+")":2===t?g.pop()+" "+g.pop():rangeToString(t))}return o();function o(){return g.pop().replace(/^\((.+)\)$/,"$1")}
/******/ 		}
/******/ 		var satisfy = (range, version) => {
/******/ 			// see webpack/lib/util/semver.js for original code
/******/ 			if(0 in range){version=parseVersion(version);var e=range[0],r=e<0;r&&(e=-e-1);for(var n=0,i=1,a=!0;;i++,n++){var f,s,g=i<range.length?(typeof range[i])[0]:"";if(n>=version.length||"o"==(s=(typeof(f=version[n]))[0]))return!a||("u"==g?i>e&&!r:""==g!=r);if("u"==s){if(!a||"u"!=g)return!1}else if(a)if(g==s)if(i<=e){if(f!=range[i])return!1}else{if(r?f>range[i]:f<range[i])return!1;f!=range[i]&&(a=!1)}else if("s"!=g&&"n"!=g){if(r||i<=e)return!1;a=!1,i--}else{if(i<=e||s<g!=r)return!1;a=!1}else"s"!=g&&"n"!=g&&(a=!1,i--)}}var t=[],o=t.pop.bind(t);for(n=1;n<range.length;n++){var u=range[n];t.push(1==u?o()|o():2==u?o()&o():u?satisfy(u,version):!o())}return!!o();
/******/ 		}
/******/ 		var ensureExistence = (scopeName, key) => {
/******/ 			var scope = __webpack_require__.S[scopeName];
/******/ 			if(!scope || !__webpack_require__.o(scope, key)) throw new Error("Shared module " + key + " doesn't exist in shared scope " + scopeName);
/******/ 			return scope;
/******/ 		};
/******/ 		var findVersion = (scope, key) => {
/******/ 			var versions = scope[key];
/******/ 			var key = Object.keys(versions).reduce((a, b) => {
/******/ 				return !a || versionLt(a, b) ? b : a;
/******/ 			}, 0);
/******/ 			return key && versions[key]
/******/ 		};
/******/ 		var findSingletonVersionKey = (scope, key) => {
/******/ 			var versions = scope[key];
/******/ 			return Object.keys(versions).reduce((a, b) => {
/******/ 				return !a || (!versions[a].loaded && versionLt(a, b)) ? b : a;
/******/ 			}, 0);
/******/ 		};
/******/ 		var getInvalidSingletonVersionMessage = (scope, key, version, requiredVersion) => {
/******/ 			return "Unsatisfied version " + version + " from " + (version && scope[key][version].from) + " of shared singleton module " + key + " (required " + rangeToString(requiredVersion) + ")"
/******/ 		};
/******/ 		var getSingleton = (scope, scopeName, key, requiredVersion) => {
/******/ 			var version = findSingletonVersionKey(scope, key);
/******/ 			return get(scope[key][version]);
/******/ 		};
/******/ 		var getSingletonVersion = (scope, scopeName, key, requiredVersion) => {
/******/ 			var version = findSingletonVersionKey(scope, key);
/******/ 			if (!satisfy(requiredVersion, version)) warn(getInvalidSingletonVersionMessage(scope, key, version, requiredVersion));
/******/ 			return get(scope[key][version]);
/******/ 		};
/******/ 		var getStrictSingletonVersion = (scope, scopeName, key, requiredVersion) => {
/******/ 			var version = findSingletonVersionKey(scope, key);
/******/ 			if (!satisfy(requiredVersion, version)) throw new Error(getInvalidSingletonVersionMessage(scope, key, version, requiredVersion));
/******/ 			return get(scope[key][version]);
/******/ 		};
/******/ 		var findValidVersion = (scope, key, requiredVersion) => {
/******/ 			var versions = scope[key];
/******/ 			var key = Object.keys(versions).reduce((a, b) => {
/******/ 				if (!satisfy(requiredVersion, b)) return a;
/******/ 				return !a || versionLt(a, b) ? b : a;
/******/ 			}, 0);
/******/ 			return key && versions[key]
/******/ 		};
/******/ 		var getInvalidVersionMessage = (scope, scopeName, key, requiredVersion) => {
/******/ 			var versions = scope[key];
/******/ 			return "No satisfying version (" + rangeToString(requiredVersion) + ") of shared module " + key + " found in shared scope " + scopeName + ".\n" +
/******/ 				"Available versions: " + Object.keys(versions).map((key) => {
/******/ 				return key + " from " + versions[key].from;
/******/ 			}).join(", ");
/******/ 		};
/******/ 		var getValidVersion = (scope, scopeName, key, requiredVersion) => {
/******/ 			var entry = findValidVersion(scope, key, requiredVersion);
/******/ 			if(entry) return get(entry);
/******/ 			throw new Error(getInvalidVersionMessage(scope, scopeName, key, requiredVersion));
/******/ 		};
/******/ 		var warn = (msg) => {
/******/ 			if (typeof console !== "undefined" && console.warn) console.warn(msg);
/******/ 		};
/******/ 		var warnInvalidVersion = (scope, scopeName, key, requiredVersion) => {
/******/ 			warn(getInvalidVersionMessage(scope, scopeName, key, requiredVersion));
/******/ 		};
/******/ 		var get = (entry) => {
/******/ 			entry.loaded = 1;
/******/ 			return entry.get()
/******/ 		};
/******/ 		var init = (fn) => (function(scopeName, a, b, c) {
/******/ 			var promise = __webpack_require__.I(scopeName);
/******/ 			if (promise && promise.then) return promise.then(fn.bind(fn, scopeName, __webpack_require__.S[scopeName], a, b, c));
/******/ 			return fn(scopeName, __webpack_require__.S[scopeName], a, b, c);
/******/ 		});
/******/ 		
/******/ 		var load = /*#__PURE__*/ init((scopeName, scope, key) => {
/******/ 			ensureExistence(scopeName, key);
/******/ 			return get(findVersion(scope, key));
/******/ 		});
/******/ 		var loadFallback = /*#__PURE__*/ init((scopeName, scope, key, fallback) => {
/******/ 			return scope && __webpack_require__.o(scope, key) ? get(findVersion(scope, key)) : fallback();
/******/ 		});
/******/ 		var loadVersionCheck = /*#__PURE__*/ init((scopeName, scope, key, version) => {
/******/ 			ensureExistence(scopeName, key);
/******/ 			return get(findValidVersion(scope, key, version) || warnInvalidVersion(scope, scopeName, key, version) || findVersion(scope, key));
/******/ 		});
/******/ 		var loadSingleton = /*#__PURE__*/ init((scopeName, scope, key) => {
/******/ 			ensureExistence(scopeName, key);
/******/ 			return getSingleton(scope, scopeName, key);
/******/ 		});
/******/ 		var loadSingletonVersionCheck = /*#__PURE__*/ init((scopeName, scope, key, version) => {
/******/ 			ensureExistence(scopeName, key);
/******/ 			return getSingletonVersion(scope, scopeName, key, version);
/******/ 		});
/******/ 		var loadStrictVersionCheck = /*#__PURE__*/ init((scopeName, scope, key, version) => {
/******/ 			ensureExistence(scopeName, key);
/******/ 			return getValidVersion(scope, scopeName, key, version);
/******/ 		});
/******/ 		var loadStrictSingletonVersionCheck = /*#__PURE__*/ init((scopeName, scope, key, version) => {
/******/ 			ensureExistence(scopeName, key);
/******/ 			return getStrictSingletonVersion(scope, scopeName, key, version);
/******/ 		});
/******/ 		var loadVersionCheckFallback = /*#__PURE__*/ init((scopeName, scope, key, version, fallback) => {
/******/ 			if(!scope || !__webpack_require__.o(scope, key)) return fallback();
/******/ 			return get(findValidVersion(scope, key, version) || warnInvalidVersion(scope, scopeName, key, version) || findVersion(scope, key));
/******/ 		});
/******/ 		var loadSingletonFallback = /*#__PURE__*/ init((scopeName, scope, key, fallback) => {
/******/ 			if(!scope || !__webpack_require__.o(scope, key)) return fallback();
/******/ 			return getSingleton(scope, scopeName, key);
/******/ 		});
/******/ 		var loadSingletonVersionCheckFallback = /*#__PURE__*/ init((scopeName, scope, key, version, fallback) => {
/******/ 			if(!scope || !__webpack_require__.o(scope, key)) return fallback();
/******/ 			return getSingletonVersion(scope, scopeName, key, version);
/******/ 		});
/******/ 		var loadStrictVersionCheckFallback = /*#__PURE__*/ init((scopeName, scope, key, version, fallback) => {
/******/ 			var entry = scope && __webpack_require__.o(scope, key) && findValidVersion(scope, key, version);
/******/ 			return entry ? get(entry) : fallback();
/******/ 		});
/******/ 		var loadStrictSingletonVersionCheckFallback = /*#__PURE__*/ init((scopeName, scope, key, version, fallback) => {
/******/ 			if(!scope || !__webpack_require__.o(scope, key)) return fallback();
/******/ 			return getStrictSingletonVersion(scope, scopeName, key, version);
/******/ 		});
/******/ 		var installedModules = {};
/******/ 		var moduleToHandlerMapping = {
/******/ 			"webpack/sharing/consume/default/react": () => (loadSingletonVersionCheck("default", "react", [1,17,0,1])),
/******/ 			"webpack/sharing/consume/default/@azure/communication-common/@azure/communication-common?feee": () => (loadStrictVersionCheckFallback("default", "@azure/communication-common", [1,2,2,0], () => (Promise.all([__webpack_require__.e("vendors-node_modules_azure_core-auth_dist-esm_src_tokenCredential_js-node_modules_azure_core--293e8a"), __webpack_require__.e("vendors-node_modules_azure_communication-common_dist-esm_src_index_js"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_4181")]).then(() => (() => (__webpack_require__(/*! @azure/communication-common */ "./node_modules/@azure/communication-common/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@jupyterlab/apputils": () => (loadSingletonVersionCheck("default", "@jupyterlab/apputils", [1,3,6,3])),
/******/ 			"webpack/sharing/consume/default/@lumino/widgets": () => (loadSingletonVersionCheck("default", "@lumino/widgets", [1,1,37,2])),
/******/ 			"webpack/sharing/consume/default/@azure/logger/@azure/logger?8548": () => (loadStrictVersionCheckFallback("default", "@azure/logger", [1,1,0,4], () => (__webpack_require__.e("vendors-node_modules_azure_logger_dist-esm_src_index_js").then(() => (() => (__webpack_require__(/*! @azure/logger */ "./node_modules/@azure/logger/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72": () => (loadStrictVersionCheckFallback("default", "@fluentui/react", [1,8,109,3], () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_fluentui_date-time-utilities_lib_dateFormatting_dateFormatting_defaults_-bcc259"), __webpack_require__.e("vendors-node_modules_fluentui_react_lib_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react-dom")]).then(() => (() => (__webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@fluentui/react-file-type-icons/@fluentui/react-file-type-icons?440d": () => (loadStrictVersionCheckFallback("default", "@fluentui/react-file-type-icons", [1,8,8,17], () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_fluentui_react-file-type-icons_lib_index_js")]).then(() => (() => (__webpack_require__(/*! @fluentui/react-file-type-icons */ "./node_modules/@fluentui/react-file-type-icons/lib/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/communication-react/@azure/communication-react": () => (loadStrictVersionCheckFallback("default", "@azure/communication-react", [1,1,5,0], () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_fluentui_merge-styles_lib_Stylesheet_js-node_modules_fluentui_utilities_-879338"), __webpack_require__.e("vendors-node_modules_events_events_js"), __webpack_require__.e("vendors-node_modules_azure_communication-react_dist_dist-esm_communication-react_src_index_js"), __webpack_require__.e("webpack_sharing_consume_default_react-dom"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-calling_azure_communication-calling-webpa-831138")]).then(() => (() => (__webpack_require__(/*! @azure/communication-react */ "./node_modules/@azure/communication-react/dist/dist-esm/communication-react/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@fluentui/react-icons/@fluentui/react-icons?6c0a": () => (loadStrictVersionCheckFallback("default", "@fluentui/react-icons", [1,2,0,201], () => (__webpack_require__.e("vendors-node_modules_fluentui_react-icons_lib_index_js").then(() => (() => (__webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/logger/@azure/logger?ea28": () => (loadStrictVersionCheckFallback("default", "@azure/logger", [4,1,0,3], () => (__webpack_require__.e("node_modules_azure_communication-calling_node_modules_azure_logger_dist-esm_src_index_js-_b3270").then(() => (() => (__webpack_require__(/*! @azure/logger */ "./node_modules/@azure/communication-calling/node_modules/@azure/logger/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/communication-common/@azure/communication-common?61dd": () => (loadStrictVersionCheckFallback("default", "@azure/communication-common", [4,2,0,0], () => (Promise.all([__webpack_require__.e("vendors-node_modules_tslib_tslib_es6_js"), __webpack_require__.e("vendors-node_modules_azure_core-auth_dist-esm_src_tokenCredential_js-node_modules_azure_core--293e8a"), __webpack_require__.e("vendors-node_modules_azure_communication-calling_node_modules_azure_communication-common_dist-bdb051"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_4181")]).then(() => (() => (__webpack_require__(/*! @azure/communication-common */ "./node_modules/@azure/communication-calling/node_modules/@azure/communication-common/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/abort-controller/@azure/abort-controller": () => (loadStrictVersionCheckFallback("default", "@azure/abort-controller", [1,1,0,0], () => (__webpack_require__.e("node_modules_azure_abort-controller_dist-esm_src_index_js").then(() => (() => (__webpack_require__(/*! @azure/abort-controller */ "./node_modules/@azure/abort-controller/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/logger/@azure/logger?4181": () => (loadStrictVersionCheckFallback("default", "@azure/logger", [1,1,0,0], () => (__webpack_require__.e("vendors-node_modules_azure_logger_dist-esm_src_index_js").then(() => (() => (__webpack_require__(/*! @azure/logger */ "./node_modules/@azure/logger/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/logger/@azure/logger?56cc": () => (loadStrictVersionCheckFallback("default", "@azure/logger", [1,1,0,0], () => (__webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_azure_communication-common_node_m-3c2995").then(() => (() => (__webpack_require__(/*! @azure/logger */ "./node_modules/@azure/communication-react/node_modules/@azure/communication-common/node_modules/@azure/logger/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/react-dom": () => (loadSingletonVersionCheck("default", "react-dom", [1,17,0,1])),
/******/ 			"webpack/sharing/consume/default/@azure/communication-common/@azure/communication-common?4b03": () => (loadStrictVersionCheckFallback("default", "@azure/communication-common", [4,2,0,0], () => (Promise.all([__webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_azure_communication-common_dist-e-65f4c5"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_56cc")]).then(() => (() => (__webpack_require__(/*! @azure/communication-common */ "./node_modules/@azure/communication-react/node_modules/@azure/communication-common/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/communication-calling/@azure/communication-calling": () => (loadStrictVersionCheckFallback("default", "@azure/communication-calling", [0,1,4,4], () => (Promise.all([__webpack_require__.e("vendors-node_modules_azure_communication-calling_dist_sdk_bundle_js"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-common_azure_communication-common-webpack-bf920b")]).then(() => (() => (__webpack_require__(/*! @azure/communication-calling */ "./node_modules/@azure/communication-calling/dist/sdk.bundle.js"))))))),
/******/ 			"webpack/sharing/consume/default/@fluentui/react/@fluentui/react?1440": () => (loadStrictVersionCheckFallback("default", "@fluentui/react", [2,8,98,3], () => (Promise.all([__webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_fluentui_date-time-utilities_lib_dateFormatting_dateFormatting_defaults_-bcc259"), __webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_fluentui_react_lib_index_js")]).then(() => (() => (__webpack_require__(/*! @fluentui/react */ "./node_modules/@azure/communication-react/node_modules/@fluentui/react/lib/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/reselect/reselect": () => (loadStrictVersionCheckFallback("default", "reselect", [2,4,0,0], () => (__webpack_require__.e("node_modules_azure_communication-react_node_modules_reselect_es_index_js").then(() => (() => (__webpack_require__(/*! reselect */ "./node_modules/@azure/communication-react/node_modules/reselect/es/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@fluentui/react-file-type-icons/@fluentui/react-file-type-icons?e711": () => (loadStrictVersionCheckFallback("default", "@fluentui/react-file-type-icons", [2,8,5,8], () => (Promise.all([__webpack_require__.e("vendors-node_modules_fluentui_style-utilities_lib_index_js"), __webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_fluentui_react-file-type-icons_li-20dab2")]).then(() => (() => (__webpack_require__(/*! @fluentui/react-file-type-icons */ "./node_modules/@azure/communication-react/node_modules/@fluentui/react-file-type-icons/lib/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/react-linkify/react-linkify": () => (loadStrictVersionCheckFallback("default", "react-linkify", [1,1,0,0,,"alpha"], () => (__webpack_require__.e("vendors-node_modules_react-linkify_dist_index_js").then(() => (() => (__webpack_require__(/*! react-linkify */ "./node_modules/react-linkify/dist/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@fluentui/react-icons/@fluentui/react-icons?2fa3": () => (loadStrictVersionCheckFallback("default", "@fluentui/react-icons", [2,1,1,145], () => (__webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_fluentui_react-icons_lib_esm_index_js").then(() => (() => (__webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@azure/communication-react/node_modules/@fluentui/react-icons/lib/esm/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/logger/@azure/logger?8126": () => (loadStrictVersionCheckFallback("default", "@azure/logger", [4,1,0,3], () => (__webpack_require__.e("vendors-node_modules_azure_communication-react_node_modules_azure_logger_dist-esm_src_index_js").then(() => (() => (__webpack_require__(/*! @azure/logger */ "./node_modules/@azure/communication-react/node_modules/@azure/logger/dist-esm/src/index.js"))))))),
/******/ 			"webpack/sharing/consume/default/@azure/communication-chat/@azure/communication-chat": () => (loadStrictVersionCheckFallback("default", "@azure/communication-chat", [4,1,2,0], () => (Promise.all([__webpack_require__.e("vendors-node_modules_azure_core-auth_dist-esm_src_tokenCredential_js-node_modules_azure_core--293e8a"), __webpack_require__.e("vendors-node_modules_azure_communication-chat_dist-esm_src_index_js"), __webpack_require__.e("webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller"), __webpack_require__.e("webpack_sharing_consume_default_azure_logger_azure_logger-_4181"), __webpack_require__.e("webpack_sharing_consume_default_azure_communication-common_azure_communication-common")]).then(() => (() => (__webpack_require__(/*! @azure/communication-chat */ "./node_modules/@azure/communication-chat/dist-esm/src/index.js")))))))
/******/ 		};
/******/ 		// no consumes in initial chunks
/******/ 		var chunkMapping = {
/******/ 			"webpack_sharing_consume_default_react": [
/******/ 				"webpack/sharing/consume/default/react"
/******/ 			],
/******/ 			"webpack_sharing_consume_default_azure_communication-common_azure_communication-common": [
/******/ 				"webpack/sharing/consume/default/@azure/communication-common/@azure/communication-common?feee"
/******/ 			],
/******/ 			"lib_index_js": [
/******/ 				"webpack/sharing/consume/default/@jupyterlab/apputils",
/******/ 				"webpack/sharing/consume/default/@lumino/widgets",
/******/ 				"webpack/sharing/consume/default/@azure/logger/@azure/logger?8548",
/******/ 				"webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72",
/******/ 				"webpack/sharing/consume/default/@fluentui/react-file-type-icons/@fluentui/react-file-type-icons?440d",
/******/ 				"webpack/sharing/consume/default/@azure/communication-react/@azure/communication-react",
/******/ 				"webpack/sharing/consume/default/@fluentui/react-icons/@fluentui/react-icons?6c0a"
/******/ 			],
/******/ 			"webpack_sharing_consume_default_azure_communication-common_azure_communication-common-webpack-bf920b": [
/******/ 				"webpack/sharing/consume/default/@azure/logger/@azure/logger?ea28",
/******/ 				"webpack/sharing/consume/default/@azure/communication-common/@azure/communication-common?61dd"
/******/ 			],
/******/ 			"webpack_sharing_consume_default_azure_abort-controller_azure_abort-controller": [
/******/ 				"webpack/sharing/consume/default/@azure/abort-controller/@azure/abort-controller"
/******/ 			],
/******/ 			"webpack_sharing_consume_default_azure_logger_azure_logger-_4181": [
/******/ 				"webpack/sharing/consume/default/@azure/logger/@azure/logger?4181"
/******/ 			],
/******/ 			"webpack_sharing_consume_default_azure_logger_azure_logger-_56cc": [
/******/ 				"webpack/sharing/consume/default/@azure/logger/@azure/logger?56cc"
/******/ 			],
/******/ 			"webpack_sharing_consume_default_react-dom": [
/******/ 				"webpack/sharing/consume/default/react-dom"
/******/ 			],
/******/ 			"webpack_sharing_consume_default_azure_communication-calling_azure_communication-calling-webpa-831138": [
/******/ 				"webpack/sharing/consume/default/@azure/communication-common/@azure/communication-common?4b03",
/******/ 				"webpack/sharing/consume/default/@azure/communication-calling/@azure/communication-calling",
/******/ 				"webpack/sharing/consume/default/@fluentui/react/@fluentui/react?1440",
/******/ 				"webpack/sharing/consume/default/reselect/reselect",
/******/ 				"webpack/sharing/consume/default/@fluentui/react-file-type-icons/@fluentui/react-file-type-icons?e711",
/******/ 				"webpack/sharing/consume/default/react-linkify/react-linkify",
/******/ 				"webpack/sharing/consume/default/@fluentui/react-icons/@fluentui/react-icons?2fa3",
/******/ 				"webpack/sharing/consume/default/@azure/logger/@azure/logger?8126",
/******/ 				"webpack/sharing/consume/default/@azure/communication-chat/@azure/communication-chat"
/******/ 			]
/******/ 		};
/******/ 		__webpack_require__.f.consumes = (chunkId, promises) => {
/******/ 			if(__webpack_require__.o(chunkMapping, chunkId)) {
/******/ 				chunkMapping[chunkId].forEach((id) => {
/******/ 					if(__webpack_require__.o(installedModules, id)) return promises.push(installedModules[id]);
/******/ 					var onFactory = (factory) => {
/******/ 						installedModules[id] = 0;
/******/ 						__webpack_require__.m[id] = (module) => {
/******/ 							delete __webpack_require__.c[id];
/******/ 							module.exports = factory();
/******/ 						}
/******/ 					};
/******/ 					var onError = (error) => {
/******/ 						delete installedModules[id];
/******/ 						__webpack_require__.m[id] = (module) => {
/******/ 							delete __webpack_require__.c[id];
/******/ 							throw error;
/******/ 						}
/******/ 					};
/******/ 					try {
/******/ 						var promise = moduleToHandlerMapping[id]();
/******/ 						if(promise.then) {
/******/ 							promises.push(installedModules[id] = promise.then(onFactory)['catch'](onError));
/******/ 						} else onFactory(promise);
/******/ 					} catch(e) { onError(e); }
/******/ 				});
/******/ 			}
/******/ 		}
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"jupyter-opechat": 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(!/^webpack_sharing_consume_default_(azure_(communication\-c(ommon_azure_communication\-common(|\-webpack\-bf920b)|alling_azure_communication\-calling\-webpa\-831138)|logger_azure_logger\-_(4181|56cc)|abort\-controller_azure_abort\-controller)|react(|\-dom))$/.test(chunkId)) {
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						} else installedChunks[chunkId] = 0;
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkjupyter_opechat"] = self["webpackChunkjupyter_opechat"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// module cache are used so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	var __webpack_exports__ = __webpack_require__("webpack/container/entry/jupyter-opechat");
/******/ 	(_JUPYTERLAB = typeof _JUPYTERLAB === "undefined" ? {} : _JUPYTERLAB)["jupyter-opechat"] = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=remoteEntry.6949e65786d6fe4cafbd.js.map