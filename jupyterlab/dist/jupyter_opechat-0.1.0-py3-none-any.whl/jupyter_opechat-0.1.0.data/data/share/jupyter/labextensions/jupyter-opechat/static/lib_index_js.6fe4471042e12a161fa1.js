"use strict";
(self["webpackChunkjupyter_opechat"] = self["webpackChunkjupyter_opechat"] || []).push([["lib_index_js"],{

/***/ "./lib/app/App.js":
/*!************************!*\
  !*** ./lib/app/App.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _azure_logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @azure/logger */ "webpack/sharing/consume/default/@azure/logger/@azure/logger?8548");
/* harmony import */ var _azure_logger__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_azure_logger__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ChatScreen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ChatScreen */ "./lib/app/ChatScreen.js");
/* harmony import */ var _ConfigurationScreen__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ConfigurationScreen */ "./lib/app/ConfigurationScreen.js");
/* harmony import */ var _ErrorScreen__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ErrorScreen */ "./lib/app/ErrorScreen.js");
/* harmony import */ var _fluentui_react_file_type_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-file-type-icons */ "webpack/sharing/consume/default/@fluentui/react-file-type-icons/@fluentui/react-file-type-icons?440d");
/* harmony import */ var _fluentui_react_file_type_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_file_type_icons__WEBPACK_IMPORTED_MODULE_3__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.







(0,_azure_logger__WEBPACK_IMPORTED_MODULE_0__.setLogLevel)('warning');
(0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.initializeIcons)();
(0,_fluentui_react_file_type_icons__WEBPACK_IMPORTED_MODULE_3__.initializeFileTypeIcons)();
const ERROR_PAGE_TITLE_REMOVED = 'You have been removed from the chat.';
const webAppTitle = document.title;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (() => {
    const [page, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('configuration');
    const [token, setToken] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [userId, setUserId] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [displayName, setDisplayName] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [threadId, setThreadId] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [endpointUrl, setEndpointUrl] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [userEmail, setUserEmail] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const renderPage = () => {
        switch (page) {
            case 'configuration': {
                document.title = `configuration - ${webAppTitle}`;
                return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_ConfigurationScreen__WEBPACK_IMPORTED_MODULE_4__["default"], { joinChatHandler: () => {
                        console.log('Jump to chat window');
                        setPage('chat');
                    }, setToken: setToken, setUserId: setUserId, setDisplayName: setDisplayName, setThreadId: setThreadId, setEndpointUrl: setEndpointUrl, setUserEmail: setUserEmail }));
            }
            case 'chat': {
                document.title = `chat - ${webAppTitle}`;
                if (token && userId && displayName && threadId && endpointUrl) {
                    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_ChatScreen__WEBPACK_IMPORTED_MODULE_5__.ChatScreen, { token: token, email: userEmail, userId: userId, displayName: displayName, endpointUrl: endpointUrl, threadId: threadId, endChatHandler: isParticipantRemoved => {
                            if (isParticipantRemoved) {
                                setPage('removed');
                            }
                            else {
                                setPage('end');
                            }
                        } }));
                }
                return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Spinner, { label: 'Loading...', ariaLive: "assertive", labelPosition: "top" }));
            }
            case 'removed': {
                document.title = `removed - ${webAppTitle}`;
                return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_ErrorScreen__WEBPACK_IMPORTED_MODULE_6__.ErrorScreen, { title: ERROR_PAGE_TITLE_REMOVED, homeHandler: () => {
                        window.location.href = window.location.origin;
                    } }));
            }
            default:
                document.title = `error - ${webAppTitle}`;
                throw new Error('Page type not recognized');
        }
    };
    return renderPage();
});


/***/ }),

/***/ "./lib/app/ChatScreen.js":
/*!*******************************!*\
  !*** ./lib/app/ChatScreen.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatScreen: () => (/* binding */ ChatScreen)
/* harmony export */ });
/* harmony import */ var _azure_communication_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @azure/communication-react */ "webpack/sharing/consume/default/@azure/communication-react/@azure/communication-react");
/* harmony import */ var _azure_communication_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_ChatScreen_styles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./styles/ChatScreen.styles */ "./lib/app/styles/ChatScreen.styles.js");
/* harmony import */ var _utils_credential__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/credential */ "./lib/app/utils/credential.js");
/* harmony import */ var _utils_emojiCache__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils/emojiCache */ "./lib/app/utils/emojiCache.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils/utils */ "./lib/app/utils/utils.js");
/* harmony import */ var _theming_SwitchableFluentThemeProvider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./theming/SwitchableFluentThemeProvider */ "./lib/app/theming/SwitchableFluentThemeProvider.js");
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.








const ChatScreen = (props) => {
    const { email, displayName, endpointUrl, threadId, token, userId, endChatHandler } = props;
    const { currentTheme } = (0,_theming_SwitchableFluentThemeProvider__WEBPACK_IMPORTED_MODULE_3__.useSwitchableFluentTheme)();
    const adapterAfterCreate = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async (adapter) => {
        adapter.on('participantsRemoved', listener => {
            const removedParticipantIds = listener.participantsRemoved.map(p => (0,_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__.toFlatCommunicationIdentifier)(p.id));
            if (removedParticipantIds.includes(userId)) {
                const removedBy = (0,_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__.toFlatCommunicationIdentifier)(listener.removedBy.id);
                endChatHandler(removedBy !== userId);
            }
        });
        adapter.on('error', e => {
            console.error(e);
        });
        return adapter;
    }, [endChatHandler, userId]);
    const adapterArgs = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => ({
        endpoint: endpointUrl,
        userId: (0,_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__.fromFlatCommunicationIdentifier)(userId),
        displayName,
        credential: (0,_utils_credential__WEBPACK_IMPORTED_MODULE_4__.createAutoRefreshingCredential)(userId, token),
        threadId
    }), [endpointUrl, userId, displayName, token, threadId]);
    const adapter = (0,_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__.useAzureCommunicationChatAdapter)(adapterArgs, adapterAfterCreate);
    // Dispose of the adapter in the window's before unload event
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
        const disposeAdapter = () => adapter?.dispose();
        window.addEventListener('beforeunload', disposeAdapter);
        return () => window.removeEventListener('beforeunload', disposeAdapter);
    }, [adapter]);
    if (adapter) {
        const onFetchAvatarPersonaData = (userId) => (0,_utils_emojiCache__WEBPACK_IMPORTED_MODULE_5__.fetchEmojiForUser)(email).then(emoji => new Promise(resolve => {
            return resolve({
                imageInitials: emoji,
                initialsColor: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__.getBackgroundColor)(emoji)?.backgroundColor
            });
        }));
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { className: _styles_ChatScreen_styles__WEBPACK_IMPORTED_MODULE_7__.chatScreenContainerStyle },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack.Item, { className: _styles_ChatScreen_styles__WEBPACK_IMPORTED_MODULE_7__.chatCompositeContainerStyle, role: "main" },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__.ChatComposite, { adapter: adapter, fluentTheme: currentTheme.theme, options: {
                        autoFocus: 'sendBoxTextField'
                    }, onFetchAvatarPersonaData: onFetchAvatarPersonaData }))));
    }
    return react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null, "Initializing...");
};


/***/ }),

/***/ "./lib/app/ConfigurationScreen.js":
/*!****************************************!*\
  !*** ./lib/app/ConfigurationScreen.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/utils */ "./lib/app/utils/utils.js");
/* harmony import */ var _azure_communication_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @azure/communication-react */ "webpack/sharing/consume/default/@azure/communication-react/@azure/communication-react");
/* harmony import */ var _azure_communication_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./styles/ConfigurationScreen.styles */ "./lib/app/styles/ConfigurationScreen.styles.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-icons */ "webpack/sharing/consume/default/@fluentui/react-icons/@fluentui/react-icons?6c0a");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _DisplayNameField__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./DisplayNameField */ "./lib/app/DisplayNameField.js");
/* harmony import */ var _utils_getLoginInfo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils/getLoginInfo */ "./lib/app/utils/getLoginInfo.js");
/* harmony import */ var _utils_getEndpointUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils/getEndpointUrl */ "./lib/app/utils/getEndpointUrl.js");
/* harmony import */ var _utils_setEmoji__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./utils/setEmoji */ "./lib/app/utils/setEmoji.js");
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.











// ConfigurationScreen states
const CONFIGURATIONSCREEN_SHOWING_SPINNER_LOADING = 1;
const CONFIGURATIONSCREEN_SHOWING_JOIN_CHAT = 2;
const CONFIGURATIONSCREEN_SHOWING_INVALID_THREAD = 3;
const CONFIGURATIONSCREEN_SHOWING_SPINNER_INITIALIZE_CHAT = 4;
const AVATAR_LABEL = 'Avatar';
const ERROR_TEXT_THREAD_INVALID = 'Thread Id is not valid, please revisit home page to create a new thread';
// const ERROR_TEXT_THREAD_NOT_RECORDED = 'Thread id is not recorded in server';
const ERROR_TEXT_THREAD_NULL = 'Thread id is null';
const INITIALIZE_CHAT_SPINNER_LABEL = 'Initializing chat client...';
const JOIN_BUTTON_TEXT = 'Join chat';
const LOADING_SPINNER_LABEL = 'Loading...';
const NAME_DEFAULT = 'Name';
const PROFILE_LABEL = 'Your profile';
const EMAIL_TEXTFIELD_LABEL = 'Email';
const EMAIL_TEXTFIELD_ID = 'displayName';
const EMAIL_TEXTFIELD_PLACEHOLDER = 'Enter your email';
const EMAIL_TEXTFIELD_EMPTY_ERROR_MSG = 'Email cannot be empty';
const SUBMISSION_PASSWORD_TEXTFIELD_LABEL = 'Submission Password';
const SUBMISSION_PASSWORD_TEXTFIELD_ID = 'submissionPassword';
const SUBMISSION_PASSWORD_TEXTFIELD_PLACEHOLDER = 'Enter your submission password';
const SUBMISSION_PASSWORD_TEXTFIELD_EMPTY_ERROR_MSG = 'Password cannot be empty';
const ERROR_PASSWORD_INCORRECT = 'Password is incorrect';
/**
 * There are four states of ConfigurationScreen.
 * 1. Loading configuration screen state. This will show 'loading' spinner on the screen.
 * 2. Join chat screen. This will show a name selector.
 * 3. Invalid thread state. This will show 'thread id is not valid' on the screen.
 * 4. Loading chat spinner. This will show 'initializing chat client' spinner on the screen.
 *
 * @param props
 */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const avatarsList = [_utils_utils__WEBPACK_IMPORTED_MODULE_4__.CAT, _utils_utils__WEBPACK_IMPORTED_MODULE_4__.MOUSE, _utils_utils__WEBPACK_IMPORTED_MODULE_4__.KOALA, _utils_utils__WEBPACK_IMPORTED_MODULE_4__.OCTOPUS, _utils_utils__WEBPACK_IMPORTED_MODULE_4__.MONKEY, _utils_utils__WEBPACK_IMPORTED_MODULE_4__.FOX];
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [submissionPassword, setSubmissionPassword] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [emptyEmailWarning, setEmptyEmailWarning] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [emptySubmissionPasswordWarning, setEmptySubmissionPasswordWarning] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [selectedAvatar, setSelectedAvatar] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(_utils_utils__WEBPACK_IMPORTED_MODULE_4__.CAT);
    const [configurationScreenState, setConfigurationScreenState] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(CONFIGURATIONSCREEN_SHOWING_JOIN_CHAT);
    const [disableJoinChatButton, setDisableJoinChatButton] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const theme = (0,_azure_communication_react__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
    const { joinChatHandler, setToken, setUserId, setDisplayName, setThreadId, setEndpointUrl, setUserEmail } = props;
    // Used when new user is being registered.
    const setupAndJoinChatThreadWithNewUser = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(() => {
        const internalSetupAndJoinChatThread = async () => {
            setUserEmail(email);
            const loginInfo = await (0,_utils_getLoginInfo__WEBPACK_IMPORTED_MODULE_5__.getLoginInfo)(email, submissionPassword);
            if (loginInfo.id === '') {
                setConfigurationScreenState(CONFIGURATIONSCREEN_SHOWING_JOIN_CHAT);
                setDisableJoinChatButton(false);
                throw new Error(ERROR_PASSWORD_INCORRECT);
            }
            if (!loginInfo.chatThreadID) {
                setConfigurationScreenState(CONFIGURATIONSCREEN_SHOWING_JOIN_CHAT);
                setDisableJoinChatButton(false);
                throw new Error(ERROR_TEXT_THREAD_NULL);
            }
            setToken(loginInfo.token);
            setUserId(loginInfo.id);
            setDisplayName(loginInfo.displayName);
            setThreadId(loginInfo.chatThreadID);
            const endpoint = await (0,_utils_getEndpointUrl__WEBPACK_IMPORTED_MODULE_6__.getEndpointUrl)();
            setEndpointUrl(endpoint);
            await (0,_utils_setEmoji__WEBPACK_IMPORTED_MODULE_7__.sendEmojiRequest)(email, selectedAvatar);
            // const result = await joinThread(threadId, token.identity, name);
            // if (!result) {
            //   setConfigurationScreenState(CONFIGURATIONSCREEN_SHOWING_INVALID_THREAD);
            //   setDisableJoinChatButton(false);
            //   return;
            // }
            setDisableJoinChatButton(false);
            joinChatHandler();
        };
        internalSetupAndJoinChatThread();
    }, [
        email,
        submissionPassword,
        setToken,
        setUserId,
        setDisplayName,
        setThreadId,
        setEndpointUrl,
        selectedAvatar,
        joinChatHandler,
        setUserEmail
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
        if (configurationScreenState === CONFIGURATIONSCREEN_SHOWING_SPINNER_LOADING) {
            const setScreenState = async () => {
                setConfigurationScreenState(CONFIGURATIONSCREEN_SHOWING_JOIN_CHAT);
            };
            setScreenState();
        }
    }, [configurationScreenState]);
    const smallAvatarContainerClassName = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((avatar) => {
        return (0,_styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.smallAvatarContainerStyle)(avatar, selectedAvatar, theme);
    }, [selectedAvatar, theme]);
    const validateCredentials = () => {
        if (!email || !submissionPassword) {
            if (!email) {
                setEmptyEmailWarning(true);
            }
            if (!submissionPassword) {
                setEmptySubmissionPasswordWarning(true);
            }
        }
        else {
            setEmptyEmailWarning(false);
            setEmptySubmissionPasswordWarning(false);
            setDisableJoinChatButton(true);
            setConfigurationScreenState(CONFIGURATIONSCREEN_SHOWING_SPINNER_INITIALIZE_CHAT);
            setupAndJoinChatThreadWithNewUser();
        }
    };
    const onAvatarChange = (newAvatar) => {
        setSelectedAvatar(newAvatar);
    };
    const displaySpinner = (spinnerLabel) => {
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Spinner, { label: spinnerLabel, ariaLive: "assertive", labelPosition: "top" }));
    };
    const displayJoinChatArea = () => {
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { horizontal: true, wrap: true, horizontalAlign: "center", verticalAlign: "center", tokens: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.responsiveLayoutStackTokens, className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.responsiveLayoutStyle },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { horizontalAlign: "center", tokens: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.leftPreviewContainerStackTokens, className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.leftPreviewContainerStyle },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Text, { role: 'heading', "aria-level": 1, className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.headerStyle }, PROFILE_LABEL),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: (0,_styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.largeAvatarContainerStyle)(selectedAvatar) },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { "aria-label": `${selectedAvatar} avatar`, className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.largeAvatarStyle }, selectedAvatar)),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Text, { className: (0,_styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.namePreviewStyle)(email !== '') }, email !== '' ? email : NAME_DEFAULT)),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.rightInputContainerStyle, tokens: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.rightInputContainerStackTokens },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Text, { id: 'avatar-list-label', className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.labelFontStyle }, AVATAR_LABEL),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.FocusZone, { direction: _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.FocusZoneDirection.horizontal },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { horizontal: true, className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.avatarListContainerStyle, tokens: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.avatarListContainerStackTokens, role: "list", "aria-labelledby": 'avatar-list-label' }, avatarsList.map((avatar, index) => (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { role: "listitem", id: avatar, key: index, "data-is-focusable": true, className: smallAvatarContainerClassName(avatar), onClick: () => onAvatarChange(avatar) },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.smallAvatarStyle }, avatar)))))),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_DisplayNameField__WEBPACK_IMPORTED_MODULE_9__.DisplayNameField, { setEmail: setEmail, setEmptyWarning: setEmptyEmailWarning, validateCredentials: validateCredentials, isEmpty: emptyEmailWarning, label: EMAIL_TEXTFIELD_LABEL, id: EMAIL_TEXTFIELD_ID, placeholder: EMAIL_TEXTFIELD_PLACEHOLDER, errorMessage: EMAIL_TEXTFIELD_EMPTY_ERROR_MSG }),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_DisplayNameField__WEBPACK_IMPORTED_MODULE_9__.DisplayNameField, { setEmail: setSubmissionPassword, setEmptyWarning: setEmptySubmissionPasswordWarning, validateCredentials: validateCredentials, isEmpty: emptySubmissionPasswordWarning, label: SUBMISSION_PASSWORD_TEXTFIELD_LABEL, id: SUBMISSION_PASSWORD_TEXTFIELD_ID, placeholder: SUBMISSION_PASSWORD_TEXTFIELD_PLACEHOLDER, errorMessage: SUBMISSION_PASSWORD_TEXTFIELD_EMPTY_ERROR_MSG }),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PrimaryButton, { disabled: disableJoinChatButton, className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.buttonStyle, styles: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.buttonWithIconStyles, text: JOIN_BUTTON_TEXT, onClick: validateCredentials, onRenderIcon: () => react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_3__.Chat20Filled, { className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.chatIconStyle }) }))));
    };
    const displayInvalidThreadError = () => {
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("p", null, ERROR_TEXT_THREAD_INVALID)));
    };
    const displayWithStack = (child) => {
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { className: _styles_ConfigurationScreen_styles__WEBPACK_IMPORTED_MODULE_8__.mainContainerStyle, horizontalAlign: "center", verticalAlign: "center" }, child));
    };
    if (configurationScreenState === CONFIGURATIONSCREEN_SHOWING_SPINNER_LOADING) {
        return displaySpinner(LOADING_SPINNER_LABEL);
    }
    else if (configurationScreenState === CONFIGURATIONSCREEN_SHOWING_JOIN_CHAT) {
        return displayWithStack(displayJoinChatArea());
    }
    else if (configurationScreenState === CONFIGURATIONSCREEN_SHOWING_INVALID_THREAD) {
        return displayWithStack(displayInvalidThreadError());
    }
    else if (configurationScreenState ===
        CONFIGURATIONSCREEN_SHOWING_SPINNER_INITIALIZE_CHAT) {
        return displaySpinner(INITIALIZE_CHAT_SPINNER_LABEL);
    }
    else {
        throw new Error('configuration screen state ' +
            configurationScreenState.toString() +
            ' is invalid');
    }
});


/***/ }),

/***/ "./lib/app/DisplayNameField.js":
/*!*************************************!*\
  !*** ./lib/app/DisplayNameField.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DisplayNameField: () => (/* binding */ DisplayNameField)
/* harmony export */ });
/* harmony import */ var _styles_DisplayNameField_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/DisplayNameField.styles */ "./lib/app/styles/DisplayNameField.styles.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils/constants */ "./lib/app/utils/constants.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.




// const TEXTFIELD_LABEL = 'Email';
// const TEXTFIELD_ID = 'displayName';
// const TEXTFIELD_PLACEHOLDER = 'Enter your email';
// const TEXTFIELD_EMPTY_ERROR_MSG = 'Email cannot be empty';
const DisplayNameFieldComponent = (props) => {
    const { setEmail: setEmail, setEmptyWarning, isEmpty, defaultName, validateCredentials, label, id, placeholder, errorMessage } = props;
    const onNameTextChange = (event, newValue) => {
        if (newValue === undefined) {
            return;
        }
        setEmail(newValue);
        if (!newValue) {
            setEmptyWarning(true);
        }
        else {
            setEmptyWarning(false);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.TextField, { autoComplete: "off", defaultValue: defaultName, inputClassName: _styles_DisplayNameField_styles__WEBPACK_IMPORTED_MODULE_2__.inputBoxTextStyle, label: label, className: _styles_DisplayNameField_styles__WEBPACK_IMPORTED_MODULE_2__.inputBoxStyle, onChange: onNameTextChange, id: id, placeholder: placeholder, onKeyDown: ev => {
            if (ev.which === _utils_constants__WEBPACK_IMPORTED_MODULE_3__.ENTER_KEY) {
                validateCredentials && validateCredentials();
            }
        }, styles: _styles_DisplayNameField_styles__WEBPACK_IMPORTED_MODULE_2__.TextFieldStyleProps, errorMessage: isEmpty ? errorMessage : undefined, required: true }));
};
const DisplayNameField = (props) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(DisplayNameFieldComponent, { ...props }));


/***/ }),

/***/ "./lib/app/ErrorScreen.js":
/*!********************************!*\
  !*** ./lib/app/ErrorScreen.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ErrorScreen: () => (/* binding */ ErrorScreen)
/* harmony export */ });
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/EndChat.styles */ "./lib/app/styles/EndChat.styles.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.



const ErrorScreen = (props) => {
    const goHomePage = 'Go to homepage';
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, { horizontal: true, wrap: true, horizontalAlign: "center", verticalAlign: "center", tokens: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.mainStackTokens, className: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.endChatContainerStyle },
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, { tokens: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.upperStackTokens },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, { role: 'heading', "aria-level": 1, className: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.endChatTitleStyle }, props.title),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, { horizontal: true, tokens: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.buttonsStackTokens },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.DefaultButton, { className: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.buttonStyle, styles: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.buttonWithIconStyles, text: goHomePage, onClick: props.homeHandler })),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: _styles_EndChat_styles__WEBPACK_IMPORTED_MODULE_2__.bottomStackFooterStyle },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("a", { href: "https://github.com/Azure/Communication/issues" }, "Give Feedback"),
                "\u00A0on this sample app on Github"))));
};


/***/ }),

/***/ "./lib/app/styles/ChatScreen.styles.js":
/*!*********************************************!*\
  !*** ./lib/app/styles/ChatScreen.styles.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   chatCompositeContainerStyle: () => (/* binding */ chatCompositeContainerStyle),
/* harmony export */   chatScreenContainerStyle: () => (/* binding */ chatScreenContainerStyle)
/* harmony export */ });
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

const chatScreenContainerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    height: '100%',
    width: '100%',
    paddingTop: '0.5rem',
    paddingBottom: '0.5rem'
});
const chatCompositeContainerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    width: '100%',
    height: '100%'
});


/***/ }),

/***/ "./lib/app/styles/ConfigurationScreen.styles.js":
/*!******************************************************!*\
  !*** ./lib/app/styles/ConfigurationScreen.styles.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   avatarListContainerStackTokens: () => (/* binding */ avatarListContainerStackTokens),
/* harmony export */   avatarListContainerStyle: () => (/* binding */ avatarListContainerStyle),
/* harmony export */   buttonStyle: () => (/* binding */ buttonStyle),
/* harmony export */   buttonWithIconStyles: () => (/* binding */ buttonWithIconStyles),
/* harmony export */   chatIconStyle: () => (/* binding */ chatIconStyle),
/* harmony export */   headerStyle: () => (/* binding */ headerStyle),
/* harmony export */   labelFontStyle: () => (/* binding */ labelFontStyle),
/* harmony export */   largeAvatarContainerStyle: () => (/* binding */ largeAvatarContainerStyle),
/* harmony export */   largeAvatarStyle: () => (/* binding */ largeAvatarStyle),
/* harmony export */   leftPreviewContainerStackTokens: () => (/* binding */ leftPreviewContainerStackTokens),
/* harmony export */   leftPreviewContainerStyle: () => (/* binding */ leftPreviewContainerStyle),
/* harmony export */   mainContainerStyle: () => (/* binding */ mainContainerStyle),
/* harmony export */   namePreviewStyle: () => (/* binding */ namePreviewStyle),
/* harmony export */   responsiveLayoutStackTokens: () => (/* binding */ responsiveLayoutStackTokens),
/* harmony export */   responsiveLayoutStyle: () => (/* binding */ responsiveLayoutStyle),
/* harmony export */   rightInputContainerStackTokens: () => (/* binding */ rightInputContainerStackTokens),
/* harmony export */   rightInputContainerStyle: () => (/* binding */ rightInputContainerStyle),
/* harmony export */   smallAvatarContainerStyle: () => (/* binding */ smallAvatarContainerStyle),
/* harmony export */   smallAvatarStyle: () => (/* binding */ smallAvatarStyle)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/utils */ "./lib/app/utils/utils.js");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.


const headerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    fontWeight: 600,
    fontSize: '1.5rem',
    width: '100%',
    textAlign: 'center',
    paddingBottom: '1rem'
});
const responsiveLayoutStackTokens = {
    childrenGap: '4.5rem'
};
const responsiveLayoutStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    height: '100%',
    width: '100% ',
    // half childrenGap from Stack
    padding: '2.25rem',
    // max of min-width from stack items + padding width * 2 = 20 + 2.25 * 2
    minHeight: 'auto',
    // sum of max-height of stack items + childrenGap * (#items - 1) + padding * 2 = (15.0975 + 15.875) + 4.5 * 1 + 2.25 * 2 =
    maxHeight: '39.97255rem'
});
const leftPreviewContainerStackTokens = {
    childrenGap: '0.8125rem'
};
const leftPreviewContainerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    width: '10rem',
    minHeight: '15.0975rem',
    padding: '0.5rem'
});
const rightInputContainerStackTokens = {
    childrenGap: '1.25rem'
};
const rightInputContainerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    padding: '0.5rem'
});
const avatarListContainerStackTokens = {
    childrenGap: '0.25rem'
};
const avatarListContainerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    width: '19rem'
});
const smallAvatarContainerStyle = (avatar, selectedAvatar, theme) => (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    width: '3rem',
    height: '3rem',
    border: avatar === selectedAvatar
        ? `0.125rem solid ${theme.palette.themePrimary}`
        : '',
    backgroundColor: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.getBackgroundColor)(avatar)?.backgroundColor,
    borderRadius: '50%',
    alignItems: 'center',
    display: 'flex',
    justifyContent: 'center',
    outline: 'none',
    '&:focus': {
        border: `0.1875rem solid ${theme.palette.neutralSecondary}`,
        borderRadius: theme.effects.roundedCorner4
    }
});
const largeAvatarContainerStyle = (avatar) => (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    width: '8.25rem',
    height: '8.25rem',
    backgroundColor: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.getBackgroundColor)(avatar)?.backgroundColor,
    borderRadius: '50%',
    alignItems: 'center',
    display: 'flex',
    justifyContent: 'center'
});
const smallAvatarStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    height: '1.75rem',
    width: '2rem',
    color: '#444444',
    fontWeight: 400,
    fontSize: '1.5rem',
    letterSpacing: '0',
    lineHeight: '1.75rem',
    textAlign: 'center'
});
const largeAvatarStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    height: '4.938rem',
    color: '#444444',
    fontWeight: 400,
    fontSize: '3.75rem',
    letterSpacing: '0',
    lineHeight: '4.938rem',
    textAlign: 'center'
});
const namePreviewStyle = (isEmpty) => {
    return (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
        height: '1.5rem',
        width: '8.313rem',
        fontSize: '1.125rem',
        fontWeight: 600,
        letterSpacing: '0',
        lineHeight: '1.5rem',
        textAlign: 'center',
        opacity: isEmpty ? 1 : 0.34,
        wordWrap: 'break-word',
        overflowY: 'hidden'
    });
};
const labelFontStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    fontSize: '1rem',
    fontWeight: 600,
    letterSpacing: '0',
    lineHeight: '2rem',
    minWidth: '19rem'
});
const chatIconStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    marginRight: '0.375rem',
    fontSize: '0.875rem' // 14px
});
const buttonStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    height: '2.75rem',
    fontWeight: 600,
    width: '100%',
    maxWidth: '18.75rem',
    minWidth: '12.5rem',
    fontSize: '0.875rem' // 14px
});
const buttonWithIconStyles = {
    textContainer: {
        display: 'contents'
    }
};
const mainContainerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    maxWidth: '46.875rem',
    width: '100%',
    height: '100%'
});


/***/ }),

/***/ "./lib/app/styles/DisplayNameField.styles.js":
/*!***************************************************!*\
  !*** ./lib/app/styles/DisplayNameField.styles.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TextFieldStyleProps: () => (/* binding */ TextFieldStyleProps),
/* harmony export */   inputBoxStyle: () => (/* binding */ inputBoxStyle),
/* harmony export */   inputBoxTextStyle: () => (/* binding */ inputBoxTextStyle)
/* harmony export */ });
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

const TextFieldStyleProps = {
    fieldGroup: {
        height: '2.3rem'
    }
};
const inputBoxStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    boxSizing: 'border-box',
    width: '18.75rem',
    borderRadius: '0.125rem'
});
const inputBoxTextStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    fontSize: '0.875rem',
    fontWeight: 600,
    lineHeight: '1.5rem',
    '::-webkit-input-placeholder': {
        fontSize: '0.875rem',
        fontWeight: 600
    },
    '::-moz-placeholder': {
        fontSize: '0.875rem',
        fontWeight: 600
    },
    ':-moz-placeholder': {
        fontSize: '0.875rem',
        fontWeight: 600
    }
});


/***/ }),

/***/ "./lib/app/styles/EndChat.styles.js":
/*!******************************************!*\
  !*** ./lib/app/styles/EndChat.styles.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bottomStackFooterStyle: () => (/* binding */ bottomStackFooterStyle),
/* harmony export */   buttonStyle: () => (/* binding */ buttonStyle),
/* harmony export */   buttonTextStyle: () => (/* binding */ buttonTextStyle),
/* harmony export */   buttonWithIconStyles: () => (/* binding */ buttonWithIconStyles),
/* harmony export */   buttonsStackTokens: () => (/* binding */ buttonsStackTokens),
/* harmony export */   chatIconStyle: () => (/* binding */ chatIconStyle),
/* harmony export */   endChatContainerStyle: () => (/* binding */ endChatContainerStyle),
/* harmony export */   endChatTitleStyle: () => (/* binding */ endChatTitleStyle),
/* harmony export */   mainStackTokens: () => (/* binding */ mainStackTokens),
/* harmony export */   upperStackTokens: () => (/* binding */ upperStackTokens)
/* harmony export */ });
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ "webpack/sharing/consume/default/@fluentui/react/@fluentui/react?dc72");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

const mainStackTokens = {
    childrenGap: '2.75rem'
};
const buttonsStackTokens = {
    childrenGap: '0.75rem'
};
const upperStackTokens = {
    childrenGap: '1.5rem'
};
const endChatContainerStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    height: '100%',
    width: '100% ',
    padding: '1.375rem',
    minWidth: '22.75rem',
    minHeight: 'auto'
});
const endChatTitleStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    fontWeight: 600,
    fontSize: '1.375rem',
    width: '20rem'
});
const buttonStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    fontWeight: 600,
    height: '2.5rem',
    width: '9.875rem',
    fontSize: '0.875rem',
    padding: 0
});
const buttonWithIconStyles = {
    textContainer: {
        display: 'contents'
    }
};
const chatIconStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    marginRight: '0.375rem',
    fontSize: '1.375rem' // 22px
});
const bottomStackFooterStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    fontSize: '0.875rem' // 14px
});
const buttonTextStyle = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.mergeStyles)({
    fontSize: '0.875rem' // 14px
});


/***/ }),

/***/ "./lib/app/theming/SwitchableFluentThemeProvider.js":
/*!**********************************************************!*\
  !*** ./lib/app/theming/SwitchableFluentThemeProvider.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwitchableFluentThemeProvider: () => (/* binding */ SwitchableFluentThemeProvider),
/* harmony export */   useSwitchableFluentTheme: () => (/* binding */ useSwitchableFluentTheme)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _azure_communication_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @azure/communication-react */ "webpack/sharing/consume/default/@azure/communication-react/@azure/communication-react");
/* harmony import */ var _azure_communication_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_azure_communication_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_localStorage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/localStorage */ "./lib/app/utils/localStorage.js");
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.



const defaultThemes = {
    Light: {
        name: 'Light',
        theme: _azure_communication_react__WEBPACK_IMPORTED_MODULE_1__.lightTheme
    },
    Dark: {
        name: 'Dark',
        theme: _azure_communication_react__WEBPACK_IMPORTED_MODULE_1__.darkTheme
    }
};
const defaultTheme = defaultThemes.Light;
/**
 * React useContext for FluentTheme state of SwitchableFluentThemeProvider
 */
const SwitchableFluentThemeContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
    currentTheme: defaultTheme,
    currentRtl: false,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars, @typescript-eslint/no-empty-function
    setCurrentTheme: (theme) => { },
    // eslint-disable-next-line @typescript-eslint/no-unused-vars, @typescript-eslint/no-empty-function
    setCurrentRtl: (rtl) => { },
    themeStore: defaultThemes
});
/**
 * @description Provider wrapped around FluentThemeProvider that stores themes in local storage
 * to be switched via useContext hook.
 * @param props - SwitchableFluentThemeProviderProps
 * @remarks This makes use of the browser's local storage if available
 */
const SwitchableFluentThemeProvider = (props) => {
    const { children, scopeId } = props;
    const [themeStore, setThemeCollection] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(props.themes ?? defaultThemes);
    const themeFromStorage = (0,_utils_localStorage__WEBPACK_IMPORTED_MODULE_2__.getThemeFromLocalStorage)(scopeId);
    const initialTheme = themeStore[themeFromStorage || defaultTheme.name] ?? defaultTheme;
    const [currentTheme, _setCurrentTheme] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialTheme);
    const [currentRtl, _setCurrentRtl] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const state = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
        currentTheme,
        setCurrentTheme: (namedTheme) => {
            _setCurrentTheme(namedTheme);
            // If this is a new theme, add to the theme store
            if (!themeStore[namedTheme.name]) {
                setThemeCollection({ ...themeStore, namedTheme });
            }
            // Save current selection to local storage. Note the theme itself
            // is not saved to local storage, only the name.
            if (typeof Storage !== 'undefined') {
                (0,_utils_localStorage__WEBPACK_IMPORTED_MODULE_2__.saveThemeToLocalStorage)(namedTheme.name, scopeId);
            }
        },
        currentRtl,
        setCurrentRtl: (rtl) => {
            _setCurrentRtl(rtl);
        },
        themeStore
    }), [currentTheme, currentRtl, scopeId, themeStore]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SwitchableFluentThemeContext.Provider, { value: state },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_azure_communication_react__WEBPACK_IMPORTED_MODULE_1__.FluentThemeProvider, { fluentTheme: currentTheme.theme, rtl: currentRtl }, children)));
};
/**
 * React hook for programmatically accessing the switchable fluent theme.
 */
const useSwitchableFluentTheme = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(SwitchableFluentThemeContext);


/***/ }),

/***/ "./lib/app/utils/constants.js":
/*!************************************!*\
  !*** ./lib/app/utils/constants.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ENTER_KEY: () => (/* binding */ ENTER_KEY),
/* harmony export */   StatusCode: () => (/* binding */ StatusCode)
/* harmony export */ });
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var StatusCode;
(function (StatusCode) {
    StatusCode[StatusCode["OK"] = 200] = "OK";
    StatusCode[StatusCode["CREATED"] = 201] = "CREATED";
    StatusCode[StatusCode["NOTFOUND"] = 404] = "NOTFOUND";
})(StatusCode || (StatusCode = {}));
const ENTER_KEY = 13;


/***/ }),

/***/ "./lib/app/utils/credential.js":
/*!*************************************!*\
  !*** ./lib/app/utils/credential.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createAutoRefreshingCredential: () => (/* binding */ createAutoRefreshingCredential)
/* harmony export */ });
/* harmony import */ var _azure_communication_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @azure/communication-common */ "webpack/sharing/consume/default/@azure/communication-common/@azure/communication-common?feee");
/* harmony import */ var _azure_communication_common__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_azure_communication_common__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

const postRefreshTokenParameters = {
    method: 'POST'
};
/**
 * Create credentials that auto-refresh asynchronously.
 */
const createAutoRefreshingCredential = (userId, token) => {
    const options = {
        token: token,
        tokenRefresher: refreshTokenAsync(userId),
        refreshProactively: true
    };
    return new _azure_communication_common__WEBPACK_IMPORTED_MODULE_0__.AzureCommunicationTokenCredential(options);
};
const refreshTokenAsync = (userIdentity) => {
    const params = {
        id: userIdentity
    };
    const queryString = new URLSearchParams(params).toString();
    return async () => {
        const response = await fetch(`https://ope.sailplatform.org/api/v1/refreshToken?${queryString}`, postRefreshTokenParameters);
        if (response.ok) {
            return (await response.json()).token;
        }
        else {
            throw new Error('could not refresh token');
        }
    };
};


/***/ }),

/***/ "./lib/app/utils/emojiCache.js":
/*!*************************************!*\
  !*** ./lib/app/utils/emojiCache.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchEmojiForUser: () => (/* binding */ fetchEmojiForUser)
/* harmony export */ });
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
const emojiCache = new Map();
const getEmoji = (userId) => {
    const getTokenRequestOptions = {
        method: 'GET'
    };
    const params = {
        email: userId
    };
    const queryString = new URLSearchParams(params).toString();
    return new Promise(resolve => {
        fetch(`https://ope.sailplatform.org/api/v1/profilePicture?${queryString}`, getTokenRequestOptions)
            .then(data => {
            return data.text();
        })
            .then(profilePicture => {
            resolve(profilePicture);
        })
            .catch(error => {
            console.error('Failed at getting emoji, Error: ', error);
            // Emoji defaults to '' if there was an error retrieving it from server.
            resolve('');
        });
    });
};
/**
 * Returns emoji string to caller based on userId. If emoji already exists in cache, return the cached emoji. Otherwise
 * makes a server request to get emoji. The returned emoji is a Promise<string> which may or may not be resolved so
 * caller should await it. There could potentially be many awaits happening so we may need to consider a callback style
 * approach.
 *
 * @param userId
 */
const fetchEmojiForUser = (userId) => {
    const emoji = emojiCache.get(userId);
    if (emoji === undefined) {
        const promise = getEmoji(userId);
        emojiCache.set(userId, promise);
        return promise;
    }
    else {
        return emoji;
    }
};


/***/ }),

/***/ "./lib/app/utils/getEndpointUrl.js":
/*!*****************************************!*\
  !*** ./lib/app/utils/getEndpointUrl.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getEndpointUrl: () => (/* binding */ getEndpointUrl)
/* harmony export */ });
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
let endpointUrl;
const getEndpointUrl = async () => {
    if (endpointUrl === undefined) {
        try {
            const getRequestOptions = {
                method: 'POST'
            };
            const response = await fetch('https://ope.sailplatform.org/api/v1/getEndpointUrl', getRequestOptions);
            const retrievedendpointUrl = await response
                .text()
                .then(endpointUrl => endpointUrl);
            endpointUrl = retrievedendpointUrl;
            return retrievedendpointUrl;
        }
        catch (error) {
            console.error('Failed at getting environment url, Error: ', error);
            throw new Error('Failed at getting environment url');
        }
    }
    else {
        return endpointUrl;
    }
};


/***/ }),

/***/ "./lib/app/utils/getLoginInfo.js":
/*!***************************************!*\
  !*** ./lib/app/utils/getLoginInfo.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getLoginInfo: () => (/* binding */ getLoginInfo)
/* harmony export */ });
const getLoginInfo = async (email, password) => {
    const path = window.location.pathname;
    const parts = path.split('/'); // Splits the path into parts: ["", "betatest2", "lab"]
    const session_name = parts[1];
    const params = {
        email: email,
        password: password,
        sessionName: session_name
    };
    const queryString = new URLSearchParams(params).toString();
    const options = {
        method: 'POST'
    };
    const apiUrl = `https://ope.sailplatform.org/api/v1/login?${queryString}`;
    const getLoginInfoResponse = await fetch(apiUrl, options);
    if (getLoginInfoResponse.status !== 200) {
        return {
            id: '',
            token: '',
            displayName: '',
            chatThreadID: ''
        };
    }
    const responseJson = await getLoginInfoResponse.json();
    return {
        id: responseJson.id,
        token: responseJson.token,
        displayName: responseJson.displayName,
        chatThreadID: responseJson.chatThreadID
    };
};


/***/ }),

/***/ "./lib/app/utils/localStorage.js":
/*!***************************************!*\
  !*** ./lib/app/utils/localStorage.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LocalStorageKeys: () => (/* binding */ LocalStorageKeys),
/* harmony export */   getThemeFromLocalStorage: () => (/* binding */ getThemeFromLocalStorage),
/* harmony export */   localStorageAvailable: () => (/* binding */ localStorageAvailable),
/* harmony export */   saveThemeToLocalStorage: () => (/* binding */ saveThemeToLocalStorage)
/* harmony export */ });
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
const localStorageAvailable = typeof Storage !== 'undefined';
var LocalStorageKeys;
(function (LocalStorageKeys) {
    LocalStorageKeys["Theme"] = "AzureCommunicationUI_Theme";
})(LocalStorageKeys || (LocalStorageKeys = {}));
/**
 * Get theme from local storage.
 */
const getThemeFromLocalStorage = (scopeId) => window.localStorage.getItem(LocalStorageKeys.Theme + '_' + scopeId);
/**
 * Save theme into local storage.
 */
const saveThemeToLocalStorage = (theme, scopeId) => window.localStorage.setItem(LocalStorageKeys.Theme + '_' + scopeId, theme);


/***/ }),

/***/ "./lib/app/utils/setEmoji.js":
/*!***********************************!*\
  !*** ./lib/app/utils/setEmoji.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   sendEmojiRequest: () => (/* binding */ sendEmojiRequest)
/* harmony export */ });
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
const sendEmojiRequest = async (identity, emoji) => {
    try {
        const postTokenRequestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Emoji: emoji })
        };
        const params = {
            email: identity,
            profilePicture: emoji
        };
        const queryString = new URLSearchParams(params).toString();
        await (await fetch(`https://ope.sailplatform.org/api/v1/profilePicture?${queryString}`, postTokenRequestOptions)).json;
    }
    catch (error) {
        console.error('Failed at setting emoji, Error: ', error);
    }
};


/***/ }),

/***/ "./lib/app/utils/utils.js":
/*!********************************!*\
  !*** ./lib/app/utils/utils.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CAT: () => (/* binding */ CAT),
/* harmony export */   FOX: () => (/* binding */ FOX),
/* harmony export */   KOALA: () => (/* binding */ KOALA),
/* harmony export */   MONKEY: () => (/* binding */ MONKEY),
/* harmony export */   MOUSE: () => (/* binding */ MOUSE),
/* harmony export */   OCTOPUS: () => (/* binding */ OCTOPUS),
/* harmony export */   getBackgroundColor: () => (/* binding */ getBackgroundColor)
/* harmony export */ });
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
const CAT = '🐱';
const MOUSE = '🐭';
const KOALA = '🐨';
const OCTOPUS = '🐙';
const MONKEY = '🐵';
const FOX = '🦊';
const getBackgroundColor = (avatar) => {
    switch (avatar) {
        case CAT:
            return {
                backgroundColor: 'rgb(255, 250, 228)'
            };
        case MOUSE:
            return {
                backgroundColor: 'rgb(232, 242, 249)'
            };
        case KOALA:
            return {
                backgroundColor: 'rgb(237, 232, 230)'
            };
        case OCTOPUS:
            return {
                backgroundColor: 'rgb(255, 240, 245)'
            };
        case MONKEY:
            return {
                backgroundColor: 'rgb(255, 245, 222)'
            };
        case FOX:
            return {
                backgroundColor: 'rgb(255, 231, 205)'
            };
        default:
            return {
                backgroundColor: 'rgb(255, 250, 228)'
            };
    }
};


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppWidget: () => (/* binding */ AppWidget),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _app_App__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/App */ "./lib/app/App.js");




const extension = {
    id: 'jupyter-opechat:plugin',
    autoStart: true,
    activate: async (app) => {
        addSideBar(app);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);
const addSideBar = (app) => {
    const panel = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Panel();
    panel.id = 'jupyter-opechat';
    panel.title.label = 'Chat';
    // panel.title.icon = tabIcon; // svg import
    panel.addWidget(new AppWidget());
    app.shell.add(panel, 'right', { rank: 1 });
};
class AppWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor() {
        super();
        this.addClass('height-100');
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Root, null);
    }
}
const Root = () => {
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_app_App__WEBPACK_IMPORTED_MODULE_3__["default"], null);
};


/***/ })

}]);
//# sourceMappingURL=lib_index_js.6fe4471042e12a161fa1.js.map